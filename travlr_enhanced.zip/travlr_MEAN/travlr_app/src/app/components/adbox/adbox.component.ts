import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adbox',
  templateUrl: './adbox.component.html',
  styleUrls: ['./adbox.component.css']
})
export class AdboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
