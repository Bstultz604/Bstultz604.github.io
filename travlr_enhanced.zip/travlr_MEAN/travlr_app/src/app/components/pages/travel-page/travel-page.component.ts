import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-page',
  templateUrl: './travel-page.component.html',
  styleUrls: ['./travel-page.component.css']
})
export class TravelPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
