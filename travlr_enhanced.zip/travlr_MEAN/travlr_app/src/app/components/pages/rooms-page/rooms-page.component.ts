import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rooms-page',
  templateUrl: './rooms-page.component.html',
  styleUrls: ['./rooms-page.component.css']
})
export class RoomsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
