export interface Testimonial {
  _id: string, // internal MongoDB primary key  
  author: string,
  content: string
}
